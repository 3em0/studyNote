package <PACKAGENAME>;

import java.rmi.Remote;
import java.rmi.RemoteException;

import <IMPORT>;

public interface <CLASSNAME> extends Remote
{
    <METHOD> throws RemoteException;
}
