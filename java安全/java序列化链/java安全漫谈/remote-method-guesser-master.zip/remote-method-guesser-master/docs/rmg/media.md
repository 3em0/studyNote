### rmg Media

----

This document provides some more usage examples for *remote-method-guesser* in ``gif`` format.
Notice: Some of the usage examples are probably outdated and do not conform to the current
version of *remote-method-guesser*.


### Registry Bypass

----

![registry bypass](https://tneitzel.eu/73201a92878c0aba7c3419b7403ab604/registry-bypass.gif)


### Guess and Call

----

![guess and call](https://tneitzel.eu/73201a92878c0aba7c3419b7403ab604/guess-and-call.gif)


### Bind Operation

----

![bind operation](https://tneitzel.eu/73201a92878c0aba7c3419b7403ab604/bind-operation.gif)


### Guessing Speed Comparison (rmg-v3.2.0 vs rmg-v3.3.0)

----

![speed comparison-v3.2.0](https://tneitzel.eu/73201a92878c0aba7c3419b7403ab604/rmg-v3.2.0.gif)
![speed comparison-v3.3.0](https://tneitzel.eu/73201a92878c0aba7c3419b7403ab604/rmg-v3.3.0.gif)
