package de.qtc.rmg.server.legacy;

public class StringContainer {
}
